# Deploy do sistema GRUPO APONTT no Render.com

1. Acesse https://render.com
2. Clique em 'New Web Service'
3. Conecte seu GitHub OU envie o zip e clique em 'Manual Deploy'
4. No campo de build command: 
   (deixe em branco)
5. No campo Start Command: 
   python app.py
6. Em 'Environment':
   - Adicione variável PYTHON_VERSION = 3.10
7. Faça upload também do arquivo credentials.json na raiz do projeto (não commitado se usar Git)

Acesse seu sistema pronto em: https://<nome>.onrender.com

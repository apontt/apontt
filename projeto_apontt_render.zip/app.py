from flask import Flask, render_template, request, redirect, flash, url_for
from contrato import gerar_contrato
from sheets import salvar_cliente_na_planilha
from asaas import cadastrar_cliente_asaas, gerar_cobranca
from whatsapp import enviar_mensagem

app = Flask(__name__)
app.secret_key = "apontt_secreto"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form['nome']
        cpf = request.form['cpf']
        email = request.form['email']
        telefone = request.form['telefone']
        valor = request.form['valor']
        endereco = request.form['endereco']

        salvar_cliente_na_planilha(nome, cpf, email, telefone, valor)

        cliente = cadastrar_cliente_asaas(nome, cpf, email, telefone)
        customer_id = cliente['id']

        contrato_link = gerar_contrato({
            'nome': nome,
            'cpf': cpf,
            'email': email,
            'telefone': telefone,
            'endereco': endereco,
            'valor': valor
        })

        cobranca = gerar_cobranca(customer_id, valor)
        pagamento_link = cobranca['invoiceUrl']

        enviar_mensagem(telefone, f"Olá {nome}, aqui está seu contrato: {contrato_link}\n
Link para pagamento: {pagamento_link}")

        flash("Cadastro realizado, contrato gerado e link enviado por WhatsApp!", "success")
        return redirect(url_for('index'))

    return render_template('cadastro.html')

if __name__ == "__main__":
    app.run()
